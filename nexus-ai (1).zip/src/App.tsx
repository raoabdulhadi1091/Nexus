import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { SettingsModal } from './components/SettingsModal';
import { SearchModal } from './components/SearchModal';
import {
  Conversation,
  ChatMessage as ChatMessageType,
  ReplyMode,
  AppSettings,
  AttachedFile,
  ThemePalette,
} from './types';
import {
  fetchConversations,
  saveConversation,
  deleteConversation as apiDeleteConversation,
  deleteAllConversations as apiDeleteAllConversations,
  fetchPinned,
  savePinned,
  sendChatMessage,
  exportChatToMarkdown,
} from './utils/api';
import { getPalette } from './utils/themePalettes';
import { sound } from './utils/soundEffects';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  palette: 'cyber-cyan',
  fontSize: 15,
  density: 'comfortable',
  enterToSend: true,
  defaultMode: 'General',
  ttsVoice: '',
  ttsRate: 1.0,
  ttsPitch: 1.0,
  soundEffects: true,
  streamEffect: true,
};

function createNewSessionId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'conv-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now();
}

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const [pinnedIds, setPinnedIds] = useState<string[]>([]);
  const [currentMode, setCurrentMode] = useState<ReplyMode>('General');
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('nexus_ai_settings_v2');
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const composerInputRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const palette = getPalette(settings.palette);

  // Initialize and load saved state
  useEffect(() => {
    async function init() {
      const [convList, pinned] = await Promise.all([
        fetchConversations(),
        fetchPinned(),
      ]);

      setConversations(convList);
      setPinnedIds(pinned);

      if (convList.length > 0) {
        setActiveId(convList[0].id);
      } else {
        const newId = createNewSessionId();
        const initialConv: Conversation = {
          id: newId,
          title: 'New Conversation',
          messages: [],
          updated_at: Date.now() / 1000,
        };
        setConversations([initialConv]);
        setActiveId(newId);
        saveConversation(initialConv);
      }
    }
    init();
  }, []);

  // Update CSS root variables and save settings
  useEffect(() => {
    localStorage.setItem('nexus_ai_settings_v2', JSON.stringify(settings));

    const root = document.documentElement;
    const colors = palette.colors;

    root.style.setProperty('--nexus-bg', colors.bg);
    root.style.setProperty('--nexus-bg-subtle', colors.bgSubtle);
    root.style.setProperty('--nexus-surface', colors.surface);
    root.style.setProperty('--nexus-surface-hover', colors.surfaceHover);
    root.style.setProperty('--nexus-surface-active', colors.surfaceActive);
    root.style.setProperty('--nexus-border', colors.border);
    root.style.setProperty('--nexus-border-highlight', colors.borderHighlight);
    root.style.setProperty('--nexus-text', colors.text);
    root.style.setProperty('--nexus-text-muted', colors.textMuted);
    root.style.setProperty('--nexus-primary', colors.primary);
    root.style.setProperty('--nexus-primary-hover', colors.primaryHover);
    root.style.setProperty('--nexus-primary-subtle', colors.primarySubtle);
    root.style.setProperty('--nexus-accent', colors.accent);
    root.style.setProperty('--nexus-glow', colors.glow);

    document.body.style.backgroundColor = colors.bg;
    document.body.style.color = colors.text;
  }, [settings, palette]);

  // Global keyboard shortcuts (Cmd/Ctrl+K for search, Cmd/Ctrl+Shift+O for new chat)
  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        handleNewConversation();
      }
    };
    window.addEventListener('keydown', handleGlobalKeys);
    return () => window.removeEventListener('keydown', handleGlobalKeys);
  }, [conversations]);

  // Auto-scroll chat to bottom on new messages
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [conversations, isGenerating]);

  // Get active conversation object
  const activeConversation = conversations.find((c) => c.id === activeId) || {
    id: activeId || createNewSessionId(),
    title: 'New Conversation',
    messages: [],
    updated_at: Date.now() / 1000,
  };

  // Stats calculation
  const totalMessages = activeConversation.messages.length;
  const userMessages = activeConversation.messages.filter((m) => m.role === 'user').length;
  const assistantMessages = activeConversation.messages.filter((m) => m.role === 'assistant').length;
  const isPinned = pinnedIds.includes(activeConversation.id);

  // New Conversation Handler
  const handleNewConversation = () => {
    const newId = createNewSessionId();
    const newConv: Conversation = {
      id: newId,
      title: 'New Conversation',
      messages: [],
      updated_at: Date.now() / 1000,
    };

    setConversations((prev) => [newConv, ...prev]);
    setActiveId(newId);
    saveConversation(newConv);
    composerInputRef.current?.focus();
  };

  // Select existing conversation
  const handleSelectConversation = (id: string) => {
    setActiveId(id);
  };

  // Delete conversation
  const handleDeleteConversation = async (id: string) => {
    await apiDeleteConversation(id);
    const updated = conversations.filter((c) => c.id !== id);
    setConversations(updated);

    if (pinnedIds.includes(id)) {
      const newPinned = pinnedIds.filter((p) => p !== id);
      setPinnedIds(newPinned);
      savePinned(newPinned);
    }

    if (activeId === id) {
      if (updated.length > 0) {
        setActiveId(updated[0].id);
      } else {
        handleNewConversation();
      }
    }
  };

  // Delete all conversations
  const handleDeleteAllConversations = async () => {
    await apiDeleteAllConversations();
    setPinnedIds([]);
    handleNewConversation();
  };

  // Toggle Pin
  const handleTogglePin = async (id?: string) => {
    const targetId = id || activeConversation.id;
    let nextPinned: string[];
    if (pinnedIds.includes(targetId)) {
      nextPinned = pinnedIds.filter((p) => p !== targetId);
    } else {
      nextPinned = [...pinnedIds, targetId];
    }
    setPinnedIds(nextPinned);
    await savePinned(nextPinned);
  };

  // Update Title
  const handleUpdateTitle = (newTitle: string) => {
    const updatedConv: Conversation = {
      ...activeConversation,
      title: newTitle,
      updated_at: Date.now() / 1000,
    };
    setConversations((prev) => prev.map((c) => (c.id === updatedConv.id ? updatedConv : c)));
    saveConversation(updatedConv);
  };

  // Send Message
  const handleSendMessage = async (text: string, file?: AttachedFile) => {
    if ((!text.trim() && !file) || isGenerating) return;

    const userMessage: ChatMessageType = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: text.trim() || '📎 File attached',
      ts: Date.now() / 1000,
      file_info: file ? `${file.name} • ${(file.size / 1024).toFixed(1)} KB` : undefined,
      image_b64: file?.isImage ? file.content : undefined,
      file,
    };

    // Auto title generation on first message
    let newTitle = activeConversation.title;
    if (activeConversation.title === 'New Conversation' || !activeConversation.title) {
      if (text.trim()) {
        newTitle = text.trim().length > 45 ? text.trim().slice(0, 45) + '...' : text.trim();
      } else if (file) {
        newTitle = file.name;
      }
    }

    const updatedMessages = [...activeConversation.messages, userMessage];
    const updatedConv: Conversation = {
      ...activeConversation,
      title: newTitle,
      messages: updatedMessages,
      updated_at: Date.now() / 1000,
    };

    setConversations((prev) =>
      prev.map((c) => (c.id === updatedConv.id ? updatedConv : c))
    );
    saveConversation(updatedConv);

    // Call backend via abortable signal
    setIsGenerating(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await sendChatMessage(
        text,
        activeConversation.id,
        currentMode,
        file,
        controller.signal
      );

      if (settings.soundEffects) sound.receive();

      const assistantMessage: ChatMessageType = {
        id: 'msg-bot-' + Date.now(),
        role: 'assistant',
        content: response.reply,
        ts: Date.now() / 1000,
        isError: response.status === 'error',
      };

      const finalMessages = [...updatedMessages, assistantMessage];
      const finalConv: Conversation = {
        ...updatedConv,
        messages: finalMessages,
        updated_at: Date.now() / 1000,
      };

      setConversations((prev) =>
        prev.map((c) => (c.id === finalConv.id ? finalConv : c))
      );
      saveConversation(finalConv);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        const errorMsg: ChatMessageType = {
          id: 'msg-err-' + Date.now(),
          role: 'assistant',
          content: `⚠️ NEXUS AI couldn't complete that request. Please try again.`,
          ts: Date.now() / 1000,
          isError: true,
        };
        const finalMessages = [...updatedMessages, errorMsg];
        const finalConv = { ...updatedConv, messages: finalMessages };
        setConversations((prev) =>
          prev.map((c) => (c.id === finalConv.id ? finalConv : c))
        );
        saveConversation(finalConv);
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  // Stop Generation
  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const stopMsg: ChatMessageType = {
      id: 'msg-stop-' + Date.now(),
      role: 'assistant',
      content: '⏹️ *Response generation stopped.*',
      ts: Date.now() / 1000,
    };

    const finalMessages = [...activeConversation.messages, stopMsg];
    const finalConv = {
      ...activeConversation,
      messages: finalMessages,
      updated_at: Date.now() / 1000,
    };

    setConversations((prev) =>
      prev.map((c) => (c.id === finalConv.id ? finalConv : c))
    );
    saveConversation(finalConv);
    setIsGenerating(false);
    abortControllerRef.current = null;
  };

  // Feedback up/down handler
  const handleFeedback = (index: number, feedback: 'up' | 'down') => {
    const updatedMessages = [...activeConversation.messages];
    if (updatedMessages[index]) {
      updatedMessages[index] = {
        ...updatedMessages[index],
        feedback: updatedMessages[index].feedback === feedback ? null : feedback,
      };
      const updatedConv = { ...activeConversation, messages: updatedMessages };
      setConversations((prev) =>
        prev.map((c) => (c.id === updatedConv.id ? updatedConv : c))
      );
      saveConversation(updatedConv);
    }
  };

  // Delete message handler
  const handleDeleteMessage = (index: number) => {
    const updatedMessages = activeConversation.messages.filter((_, i) => i !== index);
    const updatedConv = { ...activeConversation, messages: updatedMessages };
    setConversations((prev) =>
      prev.map((c) => (c.id === updatedConv.id ? updatedConv : c))
    );
    saveConversation(updatedConv);
  };

  // Regenerate last response
  const handleRegenerate = () => {
    if (activeConversation.messages.length < 2 || isGenerating) return;

    let lastUserMessage: ChatMessageType | null = null;
    for (let i = activeConversation.messages.length - 1; i >= 0; i--) {
      if (activeConversation.messages[i].role === 'user') {
        lastUserMessage = activeConversation.messages[i];
        break;
      }
    }

    if (!lastUserMessage) return;

    const trimmedMessages = activeConversation.messages.slice(0, -1);
    const updatedConv = { ...activeConversation, messages: trimmedMessages };
    setConversations((prev) =>
      prev.map((c) => (c.id === updatedConv.id ? updatedConv : c))
    );

    handleSendMessage(lastUserMessage.content, lastUserMessage.file);
  };

  return (
    <div
      style={{
        backgroundColor: palette.colors.bg,
        color: palette.colors.text,
      }}
      className="min-h-screen flex flex-col transition-colors relative"
    >
      {/* Ambient background glow for high-contrast immersion */}
      <div
        style={{
          background: `radial-gradient(circle 600px at 50% 5%, ${palette.colors.glow}, transparent 70%)`,
        }}
        className="fixed inset-0 pointer-events-none z-0 opacity-40"
      />

      {/* Sidebar */}
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        pinnedIds={pinnedIds}
        currentMode={currentMode}
        settings={settings}
        isOpen={isMobileSidebarOpen}
        searchQuery={searchQuery}
        onSelectConversation={handleSelectConversation}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        onDeleteAllConversations={handleDeleteAllConversations}
        onTogglePin={handleTogglePin}
        onModeChange={(mode) => setCurrentMode(mode)}
        onPaletteChange={(pal) => {
          const targetPal = getPalette(pal);
          setSettings((prev) => ({
            ...prev,
            palette: pal,
            theme: targetPal.isLight ? 'light' : 'dark',
          }));
        }}
        onExportChat={() => exportChatToMarkdown(activeConversation)}
        onToggleTheme={() =>
          setSettings((prev) => ({
            ...prev,
            palette: prev.theme === 'light' ? 'cyber-cyan' : 'lunar-light',
            theme: prev.theme === 'light' ? 'dark' : 'light',
          }))
        }
        onFontSizeChange={(size) => setSettings((prev) => ({ ...prev, fontSize: size }))}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
        isCollapsed={isSidebarCollapsed}
      />

      {/* Main Workspace Frame */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 relative z-10
          ${isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72 sm:lg:pl-80'}
        `}
      >
        {/* Header */}
        <Header
          title={activeConversation.title}
          totalMessages={totalMessages}
          userMessages={userMessages}
          assistantMessages={assistantMessages}
          isPinned={isPinned}
          currentMode={currentMode}
          settings={settings}
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onTogglePin={() => handleTogglePin()}
          onExportChat={() => exportChatToMarkdown(activeConversation)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onUpdateTitle={handleUpdateTitle}
          onPaletteChange={(pal) => {
            const targetPal = getPalette(pal);
            setSettings((prev) => ({
              ...prev,
              palette: pal,
              theme: targetPal.isLight ? 'light' : 'dark',
            }));
          }}
          onToggleSound={() =>
            setSettings((prev) => ({ ...prev, soundEffects: !prev.soundEffects }))
          }
        />

        {/* Scrollable Chat Area */}
        <main
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto px-4 py-6 scroll-smooth pb-44"
        >
          <div className="max-w-[1050px] mx-auto w-full">
            {activeConversation.messages.length === 0 ? (
              <WelcomeScreen
                settings={settings}
                onSelectPrompt={(promptText) => {
                  handleSendMessage(promptText);
                }}
              />
            ) : (
              <div className="space-y-4">
                {activeConversation.messages.map((message, index) => {
                  const isLastAssistant =
                    message.role === 'assistant' &&
                    index === activeConversation.messages.length - 1;

                  return (
                    <ChatMessage
                      key={message.id || index}
                      message={message}
                      index={index}
                      fontSize={settings.fontSize}
                      settings={settings}
                      isLastAssistant={isLastAssistant}
                      isGenerating={isGenerating}
                      onFeedback={handleFeedback}
                      onDeleteMessage={handleDeleteMessage}
                      onRegenerate={handleRegenerate}
                    />
                  );
                })}

                {/* Live Processing Indicator with real-time timer */}
                {isGenerating && (
                  <div className="w-full py-2 flex flex-col items-start animate-fadeIn">
                    <div
                      style={{
                        backgroundColor: palette.colors.surface,
                        borderColor: palette.colors.borderHighlight,
                        boxShadow: `0 8px 30px ${palette.colors.glow}`,
                      }}
                      className="rounded-2xl p-4 border max-w-[85%] sm:max-w-[75%]"
                    >
                      <div
                        style={{ color: palette.colors.primary }}
                        className="flex items-center justify-between gap-4 text-xs font-bold mb-1.5"
                      >
                        <div className="flex items-center gap-2">
                          <span
                            style={{ backgroundColor: palette.colors.primary }}
                            className="w-2.5 h-2.5 rounded-full animate-ping"
                          />
                          <span>NEXUS AI is thinking...</span>
                        </div>
                        <span className="font-mono text-[11px] opacity-75 font-normal">
                          n8n Agent executing
                        </span>
                      </div>
                      <div
                        style={{ color: palette.colors.textMuted }}
                        className="flex items-center gap-2 text-xs font-mono"
                      >
                        <span className="animate-pulse">Querying neural model & tool pipeline</span>
                        <div className="flex gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </main>

        {/* Fixed Bottom Composer Container */}
        <div
          style={{
            backgroundColor: `${palette.colors.bg}EE`,
            borderColor: palette.colors.border,
          }}
          className={`fixed bottom-0 right-0 left-0 z-30 transition-all duration-300 px-4 py-4 backdrop-blur-xl border-t
            ${isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72 sm:lg:pl-80'}
          `}
        >
          <ChatInput
            onSendMessage={handleSendMessage}
            onStopGeneration={handleStopGeneration}
            isGenerating={isGenerating}
            enterToSend={settings.enterToSend}
            currentMode={currentMode}
            settings={settings}
            inputRef={composerInputRef}
            onQuickAction={(actionText) => {
              if (composerInputRef.current) {
                composerInputRef.current.value = actionText;
                composerInputRef.current.focus();
              }
            }}
          />
        </div>
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) =>
          setSettings((prev) => ({ ...prev, ...newSettings }))
        }
      />

      {/* Quick Search Dialog (Cmd/Ctrl+K) */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        conversations={conversations}
        onSelectConversation={handleSelectConversation}
        settings={settings}
      />
    </div>
  );
}
