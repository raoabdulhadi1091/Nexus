export type Role = 'user' | 'assistant' | 'system';

export type ReplyMode = 'General' | 'Coder' | 'Writer' | 'Translator' | 'Roman Urdu';

export type ThemePalette = 'cyber-cyan' | 'matrix-emerald' | 'aurora-violet' | 'solar-amber' | 'lunar-light';

export interface AttachedFile {
  name: string;
  size: number;
  type: string;
  url?: string;
  content?: string; // extracted text or base64 preview
  isImage?: boolean;
  isAudio?: boolean;
}

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  ts: number;
  file_info?: string;
  image_b64?: string;
  file?: AttachedFile;
  feedback?: 'up' | 'down' | null;
  isError?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  updated_at: number;
  is_pinned?: boolean;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  palette: ThemePalette;
  fontSize: number; // 12 - 20 px
  density: 'compact' | 'comfortable' | 'spacious';
  enterToSend: boolean;
  defaultMode: ReplyMode;
  ttsVoice: string;
  ttsRate: number;
  ttsPitch: number;
  soundEffects: boolean;
  streamEffect: boolean;
}
