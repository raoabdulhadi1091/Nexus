import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Square,
  Mic,
  MicOff,
  X,
  FileText,
  Sparkles,
  Code,
  FileSpreadsheet,
  Globe,
  PenTool,
  Brain,
  HelpCircle,
  Hash,
} from 'lucide-react';
import { AttachedFile, ReplyMode, AppSettings } from '../types';
import { processUploadedFile, formatFileSize, SUPPORTED_EXTENSIONS } from '../utils/fileExtractor';
import { getPalette } from '../utils/themePalettes';
import { sound } from '../utils/soundEffects';

interface ChatInputProps {
  onSendMessage: (text: string, file?: AttachedFile) => void;
  onStopGeneration: () => void;
  isGenerating: boolean;
  enterToSend: boolean;
  currentMode: ReplyMode;
  settings: AppSettings;
  onQuickAction: (actionText: string) => void;
  inputRef?: React.RefObject<HTMLTextAreaElement | null>;
}

const QUICK_ACTIONS = [
  { label: 'Code', icon: Code, prefix: 'Write clean, robust code for: ' },
  { label: 'Debug', icon: Sparkles, prefix: 'Identify bugs and optimize: ' },
  { label: 'Explain', icon: Brain, prefix: 'Explain in simple terms step-by-step: ' },
  { label: 'Summarize', icon: FileText, prefix: 'Summarize the core takeaways: ' },
  { label: 'Analyze Data', icon: FileSpreadsheet, prefix: 'Analyze this dataset and provide statistical insights: ' },
  { label: 'Write', icon: PenTool, prefix: 'Draft a professional communication about: ' },
  { label: 'Translate', icon: Globe, prefix: 'Translate this accurately into English: ' },
];

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onStopGeneration,
  isGenerating,
  enterToSend,
  currentMode,
  settings,
  onQuickAction,
  inputRef: externalInputRef,
}) => {
  const [text, setText] = useState('');
  const [attachedFile, setAttachedFile] = useState<AttachedFile | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const localTextareaRef = useRef<HTMLTextAreaElement>(null);
  const textareaRef = externalInputRef || localTextareaRef;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const palette = getPalette(settings.palette);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 180);
      textareaRef.current.style.height = `${Math.max(newHeight, 48)}px`;
    }
  }, [text]);

  // Speech recognition setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((res: any) => res[0].transcript)
          .join('');
        setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognitionRef.current = recognition;
    }
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        if (settings.soundEffects) sound.click();
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Speech recognition error:', err);
      }
    }
  };

  const handleSend = () => {
    if ((!text.trim() && !attachedFile) || isGenerating) return;

    if (settings.soundEffects) sound.send();
    onSendMessage(text.trim(), attachedFile || undefined);
    setText('');
    setAttachedFile(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = '48px';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      if (enterToSend) {
        e.preventDefault();
        handleSend();
      }
    }
    if (e.key === 'Escape' && isGenerating) {
      e.preventDefault();
      onStopGeneration();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 200 * 1024 * 1024) {
      alert('File exceeds 200MB limit. Please upload a smaller file.');
      return;
    }

    if (settings.soundEffects) sound.click();
    const processed = await processUploadedFile(file);
    setAttachedFile(processed);

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (settings.soundEffects) sound.click();
      const processed = await processUploadedFile(file);
      setAttachedFile(processed);
    }
  };

  // Paste image handler
  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        const file = items[i].getAsFile();
        if (file) {
          if (settings.soundEffects) sound.click();
          const processed = await processUploadedFile(file);
          setAttachedFile(processed);
          break;
        }
      }
    }
  };

  // Word count and char count stats
  const charCount = text.length;
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
      className="relative w-full max-w-[1050px] mx-auto transition-all"
    >
      {/* Quick Action Chips Bar */}
      <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto pb-1 scrollbar-none">
        {QUICK_ACTIONS.map((action, i) => {
          const Icon = action.icon;
          return (
            <button
              key={i}
              onClick={() => {
                if (settings.soundEffects) sound.click();
                setText((prev) => (prev ? `${prev} ${action.prefix}` : action.prefix));
                textareaRef.current?.focus();
              }}
              style={{
                backgroundColor: palette.colors.surface,
                borderColor: palette.colors.border,
                color: palette.colors.text,
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border whitespace-nowrap transition-all hover:scale-105 hover:border-cyan-400 active:scale-95 shadow-sm"
            >
              <Icon size={13} style={{ color: palette.colors.primary }} />
              <span>{action.label}</span>
            </button>
          );
        })}
      </div>

      {/* Attached File Preview Card */}
      {attachedFile && (
        <div
          style={{
            backgroundColor: palette.colors.surface,
            borderColor: palette.colors.borderHighlight,
            boxShadow: `0 4px 18px ${palette.colors.glow}`,
          }}
          className="flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-2xl mb-2.5 text-xs border animate-fadeIn"
        >
          <div className="flex items-center gap-3 min-w-0">
            {attachedFile.isImage && attachedFile.url ? (
              <img
                src={attachedFile.url}
                alt="Upload preview"
                className="w-10 h-10 rounded-lg object-cover border border-white/20 shadow-sm"
              />
            ) : (
              <div
                style={{
                  backgroundColor: palette.colors.primarySubtle,
                  color: palette.colors.primary,
                }}
                className="w-10 h-10 rounded-lg flex items-center justify-center font-bold"
              >
                <FileText size={18} />
              </div>
            )}
            <div className="flex flex-col min-w-0">
              <span className="font-bold truncate max-w-[260px] sm:max-w-md">
                {attachedFile.name}
              </span>
              <span style={{ color: palette.colors.textMuted }} className="text-[11px] font-mono">
                {formatFileSize(attachedFile.size)} · Ready for Neural Analysis
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              if (settings.soundEffects) sound.click();
              setAttachedFile(null);
            }}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            title="Remove attachment"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Outer Glowing Gradient Ring */}
      <div
        style={{
          background: palette.colors.ring,
          boxShadow: isDragOver
            ? `0 0 35px ${palette.colors.glow}, 0 10px 40px rgba(0,0,0,0.6)`
            : `0 10px 35px rgba(0,0,0,0.45)`,
        }}
        className="p-[1.5px] rounded-[30px] transition-all hover:brightness-105"
      >
        {/* Inner Composer Body */}
        <div
          style={{
            backgroundColor: palette.colors.surface,
            color: palette.colors.text,
          }}
          className="flex items-end gap-2 px-3.5 py-2 rounded-[28.5px] transition-colors"
        >
          {/* File Attachment Button */}
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileChange}
            accept={SUPPORTED_EXTENSIONS.map((e) => `.${e}`).join(',')}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => {
              if (settings.soundEffects) sound.click();
              fileInputRef.current?.click();
            }}
            disabled={isGenerating}
            style={{ color: palette.colors.textMuted }}
            className="p-2.5 rounded-full hover:text-cyan-400 hover:bg-white/5 transition-all shrink-0"
            title="Attach file (PDF, DOCX, XLSX, CSV, Code, Images, Audio)"
          >
            <Paperclip size={19} />
          </button>

          {/* Text Area */}
          <div className="flex-1 flex flex-col min-w-0">
            <textarea
              ref={textareaRef}
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              onPaste={handlePaste}
              placeholder="Message NEXUS AI...  (Enter = send, Shift+Enter = new line)"
              disabled={isGenerating}
              style={{ color: palette.colors.text }}
              className="w-full py-2.5 px-2 bg-transparent resize-none focus:outline-none text-sm font-medium leading-relaxed max-h-[180px] placeholder:opacity-50"
            />
          </div>

          {/* Right Action Icons: Stats, Microphone & Send/Stop */}
          <div className="flex items-center gap-2 shrink-0 mb-1">
            {/* Real-time word / char badge when typing */}
            {charCount > 0 && (
              <span
                style={{ color: palette.colors.textMuted }}
                className="hidden sm:inline text-[10px] font-mono tabular-nums opacity-60 mr-1"
              >
                {wordCount}w · {charCount}c
              </span>
            )}

            {/* Microphone Button */}
            <button
              type="button"
              onClick={toggleListening}
              disabled={isGenerating}
              style={{
                backgroundColor: isListening ? 'rgba(239, 68, 68, 0.2)' : 'transparent',
                color: isListening ? '#EF4444' : palette.colors.textMuted,
              }}
              className={`p-2 rounded-full transition-all hover:text-white hover:bg-white/5 ${
                isListening ? 'animate-pulse' : ''
              }`}
              title={isListening ? 'Stop listening' : 'Voice input'}
            >
              {isListening ? <MicOff size={19} /> : <Mic size={19} />}
            </button>

            {/* Send OR Stop Generation Button */}
            {isGenerating ? (
              <button
                type="button"
                onClick={() => {
                  if (settings.soundEffects) sound.click();
                  onStopGeneration();
                }}
                className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/40 transition-all hover:scale-105 active:scale-95"
                title="Stop generating (Esc)"
              >
                <Square size={14} className="fill-white" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSend}
                disabled={!text.trim() && !attachedFile}
                style={{
                  background: text.trim() || attachedFile ? palette.colors.ring : 'rgba(255,255,255,0.06)',
                  boxShadow:
                    text.trim() || attachedFile ? `0 4px 20px ${palette.colors.glow}` : 'none',
                }}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  text.trim() || attachedFile
                    ? 'text-white hover:scale-105 active:scale-95 cursor-pointer hover:brightness-110'
                    : 'text-slate-600 cursor-not-allowed opacity-40'
                }`}
                title="Send message"
              >
                <Send size={16} strokeWidth={2.5} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
