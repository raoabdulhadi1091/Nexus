import React, { useState } from 'react';
import {
  Copy,
  Check,
  ThumbsUp,
  ThumbsDown,
  Volume2,
  VolumeX,
  Trash2,
  RotateCw,
  FileText,
  Share2,
} from 'lucide-react';
import { ChatMessage as ChatMessageType, AppSettings } from '../types';
import { renderMarkdown, formatTimestamp } from '../utils/markdown';
import { getPalette } from '../utils/themePalettes';
import { sound } from '../utils/soundEffects';

interface ChatMessageProps {
  message: ChatMessageType;
  index: number;
  fontSize: number;
  settings: AppSettings;
  isLastAssistant: boolean;
  isGenerating: boolean;
  onFeedback: (index: number, feedback: 'up' | 'down') => void;
  onDeleteMessage: (index: number) => void;
  onRegenerate?: () => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  index,
  fontSize,
  settings,
  isLastAssistant,
  isGenerating,
  onFeedback,
  onDeleteMessage,
  onRegenerate,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [shared, setShared] = useState(false);

  const isUser = message.role === 'user';
  const timestamp = formatTimestamp(message.ts);
  const palette = getPalette(settings.palette);

  const handleCopy = () => {
    if (settings.soundEffects) sound.click();
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (settings.soundEffects) sound.click();
    if (navigator.share) {
      navigator.share({
        title: 'NEXUS AI Response',
        text: message.content,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(message.content);
      setShared(true);
      setTimeout(() => setShared(false), 2000);
    }
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    if (settings.soundEffects) sound.click();
    window.speechSynthesis.cancel();
    // Clean markdown symbols for cleaner TTS narration
    const cleanText = message.content.replace(/[*_#`[\]()]/g, ' ').replace(/\s+/g, ' ');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = settings.ttsRate || 1.0;
    utterance.pitch = settings.ttsPitch || 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className={`w-full py-2.5 flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
      {/* Message Container with dynamic palette contrast */}
      <div
        style={{
          background: isUser ? palette.colors.userBubble : palette.colors.assistantBubble,
          borderColor: isUser ? palette.colors.borderHighlight : palette.colors.border,
          boxShadow: isUser
            ? `0 4px 20px ${palette.colors.glow}`
            : `0 4px 18px rgba(0,0,0,0.35)`,
          color: palette.colors.text,
        }}
        className={`relative max-w-[92%] sm:max-w-[82%] rounded-2xl p-4 sm:p-5 border transition-all
          ${isUser ? 'rounded-br-sm' : 'rounded-bl-sm'}
        `}
      >
        {/* Header Label: Role + Timestamp */}
        <div className="flex items-center justify-between gap-3 mb-2 text-[11px] font-bold tracking-wider">
          <div className="flex items-center gap-1.5 opacity-80">
            <span style={{ color: isUser ? '#FFFFFF' : palette.colors.primary }}>
              {isUser ? 'YOU' : '✦ NEXUS AI'}
            </span>
            {timestamp && (
              <>
                <span className="opacity-50">·</span>
                <span className="font-mono tabular-nums opacity-90">{timestamp}</span>
              </>
            )}
          </div>

          {/* User Quick Copy */}
          {isUser && (
            <button
              onClick={handleCopy}
              className="opacity-75 hover:opacity-100 transition-opacity p-0.5"
              title="Copy message"
            >
              {copied ? <Check size={12} className="text-emerald-300" /> : <Copy size={12} />}
            </button>
          )}
        </div>

        {/* Attached Image Thumbnail */}
        {message.image_b64 && (
          <div className="mb-3">
            <img
              src={`data:image/png;base64,${message.image_b64}`}
              alt="Attached content"
              onClick={() => setShowImageModal(true)}
              className="max-w-[280px] max-h-[220px] rounded-xl border border-white/20 object-cover cursor-pointer hover:opacity-90 hover:scale-[1.01] transition-all shadow-md"
            />
          </div>
        )}

        {/* Attached File Card */}
        {message.file_info && (
          <div
            style={{
              backgroundColor: isUser ? 'rgba(0, 0, 0, 0.25)' : palette.colors.surfaceHover,
              borderColor: palette.colors.border,
            }}
            className="flex items-center gap-2.5 p-2.5 rounded-xl mb-3 text-xs border"
          >
            <div
              style={{
                backgroundColor: palette.colors.primarySubtle,
                color: palette.colors.primary,
              }}
              className="p-1.5 rounded-lg"
            >
              <FileText size={16} />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-semibold truncate">{message.file_info}</span>
              <span style={{ color: palette.colors.textMuted }} className="text-[10px]">
                Processed by NEXUS AI
              </span>
            </div>
          </div>
        )}

        {/* Message Content */}
        {isUser ? (
          <div
            style={{ fontSize: `${fontSize}px` }}
            className="whitespace-pre-wrap leading-relaxed break-words font-sans text-white"
          >
            {message.content}
          </div>
        ) : (
          <div
            style={{ fontSize: `${fontSize}px` }}
            className="nexus-markdown leading-relaxed break-words"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(message.content) }}
          />
        )}
      </div>

      {/* Assistant Action Row (Exact 28x28 matching master app.py requirements) */}
      {!isUser && (
        <div className="flex items-center gap-1.5 mt-2 px-1">
          {/* Copy Button */}
          <button
            onClick={handleCopy}
            style={{
              backgroundColor: palette.colors.surface,
              borderColor: palette.colors.border,
              color: copied ? palette.colors.accent : palette.colors.textMuted,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
            title="Copy response"
          >
            {copied ? <Check size={13} strokeWidth={2.5} /> : <Copy size={13} />}
          </button>

          {/* Thumbs Up Feedback */}
          <button
            onClick={() => {
              if (settings.soundEffects) sound.click();
              onFeedback(index, 'up');
            }}
            style={{
              backgroundColor:
                message.feedback === 'up' ? palette.colors.primarySubtle : palette.colors.surface,
              borderColor:
                message.feedback === 'up' ? palette.colors.borderHighlight : palette.colors.border,
              color: message.feedback === 'up' ? palette.colors.primary : palette.colors.textMuted,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
            title="Helpful response"
          >
            <ThumbsUp size={13} />
          </button>

          {/* Thumbs Down Feedback */}
          <button
            onClick={() => {
              if (settings.soundEffects) sound.click();
              onFeedback(index, 'down');
            }}
            style={{
              backgroundColor:
                message.feedback === 'down' ? 'rgba(239, 68, 68, 0.15)' : palette.colors.surface,
              borderColor:
                message.feedback === 'down' ? 'rgba(239, 68, 68, 0.4)' : palette.colors.border,
              color: message.feedback === 'down' ? '#EF4444' : palette.colors.textMuted,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
            title="Not helpful"
          >
            <ThumbsDown size={13} />
          </button>

          {/* Text-to-Speech (TTS) */}
          <button
            onClick={handleSpeak}
            style={{
              backgroundColor: isSpeaking ? palette.colors.primarySubtle : palette.colors.surface,
              borderColor: isSpeaking ? palette.colors.borderHighlight : palette.colors.border,
              color: isSpeaking ? palette.colors.primary : palette.colors.textMuted,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
            title={isSpeaking ? 'Stop speaking' : 'Read aloud with TTS'}
          >
            {isSpeaking ? <VolumeX size={13} /> : <Volume2 size={13} />}
          </button>

          {/* Share Response */}
          <button
            onClick={handleShare}
            style={{
              backgroundColor: palette.colors.surface,
              borderColor: palette.colors.border,
              color: shared ? palette.colors.accent : palette.colors.textMuted,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
            title="Share or copy response"
          >
            {shared ? <Check size={13} /> : <Share2 size={13} />}
          </button>

          {/* Regenerate (if last response) */}
          {isLastAssistant && onRegenerate && !isGenerating && (
            <button
              onClick={() => {
                if (settings.soundEffects) sound.click();
                onRegenerate();
              }}
              style={{
                backgroundColor: palette.colors.surface,
                borderColor: palette.colors.border,
                color: palette.colors.primary,
              }}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border transition-all hover:scale-105"
              title="Regenerate response"
            >
              <RotateCw size={13} />
            </button>
          )}

          {/* Delete Message */}
          <button
            onClick={() => {
              if (settings.soundEffects) sound.click();
              onDeleteMessage(index);
            }}
            style={{
              backgroundColor: palette.colors.surface,
              borderColor: palette.colors.border,
            }}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-xs border text-slate-400 hover:text-red-400 hover:border-red-500/30 transition-all hover:scale-105"
            title="Delete this message"
          >
            <Trash2 size={13} />
          </button>
        </div>
      )}

      {/* Image Modal Lightbox */}
      {showImageModal && message.image_b64 && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 backdrop-blur-md"
          onClick={() => setShowImageModal(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={`data:image/png;base64,${message.image_b64}`}
              alt="Full size attachment"
              className="max-w-full max-h-[90vh] rounded-2xl object-contain shadow-2xl border border-white/10"
            />
            <button
              onClick={() => setShowImageModal(false)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/70 text-white hover:bg-black font-bold"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
