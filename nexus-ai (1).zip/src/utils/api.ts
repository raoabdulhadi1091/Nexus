import { Conversation, ReplyMode, AttachedFile } from '../types';

const STORAGE_KEY_CONVS = 'nexus_ai_conversations';
const STORAGE_KEY_PINNED = 'nexus_ai_pinned';

export async function sendChatMessage(
  message: string,
  sessionId: string,
  mode: ReplyMode,
  file?: AttachedFile,
  signal?: AbortSignal
): Promise<{ reply: string; status: 'ok' | 'error' }> {
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        session_id: sessionId,
        mode,
        file: file
          ? {
              name: file.name,
              size: file.size,
              type: file.type,
              content: file.content,
            }
          : undefined,
      }),
      signal,
    });

    if (!res.ok) {
      const errorJson = await res.json().catch(() => null);
      if (errorJson && errorJson.reply) {
        return { reply: errorJson.reply, status: 'error' };
      }
      return {
        reply: `⚠️ Server returned error: ${res.status} ${res.statusText}`,
        status: 'error',
      };
    }

    const data = await res.json();
    return data;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      return { reply: '⏹️ *Response generation stopped.*', status: 'ok' };
    }
    return {
      reply: `⚠️ Network error: Could not reach NEXUS AI backend (${err.message || 'connection failed'}).`,
      status: 'error',
    };
  }
}

export async function fetchConversations(): Promise<Conversation[]> {
  try {
    const res = await fetch('/api/conversations');
    if (res.ok) {
      const list = await res.json();
      localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(list));
      return list;
    }
  } catch {
    // Offline or server not ready, fallback to local storage
  }

  const cached = localStorage.getItem(STORAGE_KEY_CONVS);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      return [];
    }
  }
  return [];
}

export async function saveConversation(conv: Conversation): Promise<boolean> {
  // Update local storage first
  try {
    const cached = localStorage.getItem(STORAGE_KEY_CONVS);
    let list: Conversation[] = cached ? JSON.parse(cached) : [];
    const index = list.findIndex((c) => c.id === conv.id);
    if (index >= 0) {
      list[index] = conv;
    } else {
      list.unshift(conv);
    }
    localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(list));
  } catch (err) {
    console.error('Local save error:', err);
  }

  // Update server
  try {
    const res = await fetch('/api/conversations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(conv),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function deleteConversation(id: string): Promise<boolean> {
  try {
    const cached = localStorage.getItem(STORAGE_KEY_CONVS);
    if (cached) {
      const list: Conversation[] = JSON.parse(cached);
      const filtered = list.filter((c) => c.id !== id);
      localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(filtered));
    }
  } catch {}

  try {
    const res = await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
    return res.ok;
  } catch {
    return true;
  }
}

export async function deleteAllConversations(): Promise<boolean> {
  localStorage.removeItem(STORAGE_KEY_CONVS);
  localStorage.removeItem(STORAGE_KEY_PINNED);

  try {
    const res = await fetch('/api/conversations', { method: 'DELETE' });
    return res.ok;
  } catch {
    return true;
  }
}

export async function fetchPinned(): Promise<string[]> {
  try {
    const res = await fetch('/api/pinned');
    if (res.ok) {
      const ids = await res.json();
      localStorage.setItem(STORAGE_KEY_PINNED, JSON.stringify(ids));
      return ids;
    }
  } catch {}

  const cached = localStorage.getItem(STORAGE_KEY_PINNED);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      return [];
    }
  }
  return [];
}

export async function savePinned(ids: string[]): Promise<boolean> {
  localStorage.setItem(STORAGE_KEY_PINNED, JSON.stringify(ids));
  try {
    const res = await fetch('/api/pinned', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
    return res.ok;
  } catch {
    return true;
  }
}

export async function checkServerStatus(): Promise<{
  app: string;
  status: string;
  webhookUrl: string;
  webhookStatus: string;
  modes: string[];
} | null> {
  try {
    const res = await fetch('/api/status');
    if (res.ok) {
      return await res.json();
    }
  } catch {}
  return null;
}

export function exportChatToMarkdown(conversation: Conversation) {
  const lines = [
    `# ${conversation.title}`,
    `*Exported from NEXUS AI on ${new Date().toLocaleString()}*`,
    `*Session ID: ${conversation.id}*`,
    '',
    '---',
    '',
  ];

  for (const msg of conversation.messages) {
    const who = msg.role === 'user' ? '👤 **You**' : '✦ **NEXUS AI**';
    const time = msg.ts ? ` *(${new Date(msg.ts * 1000).toLocaleTimeString()})*` : '';
    lines.push(`${who}${time}:`);
    lines.push('');
    if (msg.file_info) {
      lines.push(`> 📎 **Attached:** ${msg.file_info}`);
      lines.push('');
    }
    lines.push(msg.content);
    lines.push('');
    lines.push('---');
    lines.push('');
  }

  const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const safeTitle = (conversation.title || 'nexus-chat').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
  a.download = `${safeTitle}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
