import { AttachedFile } from '../types';

export const SUPPORTED_EXTENSIONS = [
  'pdf',
  'txt',
  'csv',
  'xlsx',
  'xls',
  'docx',
  'json',
  'py',
  'md',
  'jpg',
  'jpeg',
  'png',
  'webp',
  'mp3',
  'wav',
  'm4a',
  'mp4',
];

export function formatFileSize(bytes: number): string {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }
  if (bytes >= 1024) {
    return `${(bytes / 1024).toFixed(2)} KB`;
  }
  return `${bytes} bytes`;
}

export function getFileExtension(filename: string): string {
  return filename.slice(((filename.lastIndexOf('.') - 1) >>> 0) + 2).toLowerCase();
}

export async function processUploadedFile(file: File): Promise<AttachedFile> {
  const ext = getFileExtension(file.name);
  const isImage = ['jpg', 'jpeg', 'png', 'webp'].includes(ext);
  const isAudio = ['mp3', 'wav', 'm4a', 'mp4'].includes(ext);

  const attached: AttachedFile = {
    name: file.name,
    size: file.size,
    type: file.type || `application/${ext}`,
    isImage,
    isAudio,
  };

  if (isImage) {
    const base64 = await readFileAsBase64(file);
    attached.url = base64;
    // Extract raw base64 data without data:image/...;base64,
    const commaIndex = base64.indexOf(',');
    attached.content = commaIndex !== -1 ? base64.slice(commaIndex + 1) : base64;
    return attached;
  }

  if (isAudio) {
    attached.url = URL.createObjectURL(file);
    return attached;
  }

  // Text-based or code files
  if (['txt', 'csv', 'json', 'py', 'md', 'html', 'js', 'ts'].includes(ext)) {
    try {
      const text = await readFileAsText(file);
      attached.content = text.slice(0, 30000);
      return attached;
    } catch (err) {
      console.error('Error reading text file:', err);
    }
  }

  // For PDF, DOCX, XLSX: read as text/binary extract or note
  try {
    const raw = await readFileAsText(file);
    // Best-effort extraction: strip non-printable characters for binary formats if text is needed
    const clean = raw.replace(/[^\x20-\x7E\t\n\r]/g, ' ').replace(/\s{2,}/g, ' ');
    if (clean.length > 50) {
      attached.content = clean.slice(0, 20000);
    }
  } catch {
    // If raw extraction fails, backend will note it
  }

  return attached;
}

function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
